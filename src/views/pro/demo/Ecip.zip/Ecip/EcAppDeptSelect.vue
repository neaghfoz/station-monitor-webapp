<template>
  <div>
    <el-select-tree
      ref="appDeptSelect"
      :value="deptId"
      :default-expand-all="options.defaultExpandAll"
      :default-expanded-keys="options.disabledValues"
      :multiple="options.multiple"
      :placeholder="options.placeholder"
      :disabled="options.disabled"
      :popover-min-width="100"
      :data="appDeptData"
      :props="options.props"
      :size="options.size"
      :disabled-values="options.disabledValues"
      :check-strictly="options.checkStrictly"
      :clearable="options.clearable"
      :filterable="options.filterable"
      @change="onChange"
    />
  </div>

</template>

<script>
import ElSelectTree from './ElSelectTree'
import { findAppDeptTree } from '@/api/sysrRquest'
import { cloneDeep } from '@/utils'
import Vue from 'vue'

export default {
  name: 'EcAppDeptSelect',
  components: { ElSelectTree },
  model: {
    prop: 'value',
    event: 'change'
  },
  props: {
    value: {
      type: [Number, String, Array],
      required: false
    },
    ecData: {
      type: Array,
      required: false
    },
    multiple: {
      type: Boolean,
      default: false,
      required: false
    },
    checkStrictly: {
      type: Boolean,
      default: false,
      required: false
    },
    disabled: {
      type: Boolean,
      default: false,
      required: false
    },
    disabledValues: {
      type: Array,
      required: false
    },
    defaultExpandAll: {
      type: Boolean,
      default: false,
      required: false
    },
    clearable: {
      type: Boolean,
      default: false,
      required: false
    },
    filterable: {
      type: Boolean,
      default: false,
      required: false
    },
    placeholder: {
      type: String,
      default: '请选择',
      required: false
    },
    size: {
      type: String,
      required: false
    },
    banRoot: {
      type: Boolean,
      default: false,
      required: false
    },
    props: {
      type: Object,
      default: () => {
        return {
          value: 'id',
          label: 'name',
          children: 'children'
        }
      }
    },
    vxeMode: { // 是否为vxeMode使用类型场景, 默认为false
      type: Boolean,
      default: false,
      required: false
    },
    //  vxeParams vxe组件传递行和对应参数
    vxeParams: Object,
    renderOpts: Object
  },
  data() {
    return {
      deptId: this.multiple ? [] : '',
      appIds: [],
      appDeptData: [],
      options: {
        multiple: false,
        checkStrictly: false,
        disabled: false,
        defaultExpandAll: false,
        clearable: false,
        filterable: false,
        banRoot: false,
        size: 'mini',
        placeholder: '请选择',
        disabledValues: [],
        props: {
          value: 'id',
          label: 'shortName',
          children: 'children'
        }
      }
    }
  },
  watch: {
    $props: {
      handler(val) {
        this.propsInitData()
      },
      deep: true
    },
    ecData() {
      this.init()
    },
    'options.ecData': {
      handler(val) {
        this.init()
      },
      deep: true
    },
    // 'options.multiple': {sysrArea
    //   handler(multiple) {
    //     this.deptId = multiple ? [] : ''
    //   },
    //   deep: true,
    //   immediate: true
    // },
    // multiple: {
    //   handler(multiple) {
    //     this.options.multiple = multiple === true
    //     if (this.options.multiple) {
    //       this.deptId = !this.value ? [] : this.value.split(',')
    //     } else {
    //       this.deptId = this.value || ''
    //     }
    //   },
    //   immediate: true
    // },
    row: {
      handler(val) {
        if (val && val[this.column.property]) {
          this.deptId = this.options.multiple ? val[this.column.property].toString().split(',') : val[this.column.property].toString()
        } else {
          this.deptId = this.options.multiple ? [] : ''
        }
      },
      immediate: true,
      deep: true
    },
    value: {
      handler(val) {
        if (val) {
          this.deptId = this.multiple ? val.toString().Split(',') : val.toString()
        } else {
          this.deptId = this.multiple ? [] : ''
        }
      },
      immediate: true
    }
  },
  created() {
    this.init()
  },
  methods: {
    init() {
      this.propsInitData()
      this.getAppDeptTree()
    },
    async getAppDeptTree() {
      if (this.options.ecData) {
        this.appDeptData = this.options.ecData
      } else {
        const res = await findAppDeptTree()
        this.appDeptData = res.data
      }
      this.appIds = this.appDeptData.map(item => item.id)
      if (this.options.banRoot) {
        this.options.disabledValues = this.appIds
      }
    },
    propsInitData() {
      if (this.vxeMode) { //  vxe 调用组件时，根据传递的renderOpts，初始化data中的属性
        const { props } = this.renderOpts
        cloneDeep(this.options, props)
      } else {
        const { $props } = this
        cloneDeep(this.options, $props)
      }
    },
    getCheckedNodes(leafOnly, includeHalfChecked) {
      return this.$refs.appDeptSelect.getCheckedNodes(leafOnly, includeHalfChecked)
    },
    getCheckedKeys(leafOnly) {
      return this.$refs.appDeptSelect.getCheckedKeys(leafOnly)
    },
    onChange(e) {
      let result
      if (this.options.multiple) {
        result = e.join()
      } else {
        result = e
      }
      if (this.vxeMode) {
        const { row, column } = this
        if (!row[column.property]) {
          Vue.set(row, column.property, result)
        } else {
          row[column.property] = result
        }
      } else {
        this.$emit('change', result, this.options.multiple ? this.$refs.appDeptSelect.getCheckedNodes() : this.$refs.appDeptSelect.getCurrentNode())
      }
    }
  }

}
</script>

<style scoped>

</style>
