<template>
  <div>
    <ec-tree-modal
      title="区域选择"
      url="api/v1/area/sysrArea/data"
      :value="value"
      :is-post="false"
      :multiple="multiple"
      :params="params"
      :exclude-id="excludeId"
      :size="size"
      :attr-name="attrName"
      clearable
      @change="onChange"
    />
  </div>
</template>

<script>
import EcTreeModal from './EcTreeModal'

export default {
  name: 'EcAreaModal',
  components: { EcTreeModal },
  model: {
    prop: 'value',
    event: 'change'
  },
  props: {
    value: {
      type: [String, Object],
      required: false
    },
    multiple: {
      type: Boolean,
      default: false,
      required: false
    },
    title: {
      type: String,
      default: '数据选择',
      required: false
    },
    size: {
      type: String,
      default: '',
      required: false
    },
    attrName: {
      type: String,
      default: 'name',
      required: false
    },
    excludeId: {
      type: String,
      required: false
    },
    params: {
      type: Object,
      default: () => {},
      required: false
    }
  },
  methods: {
    onChange(e) {
      this.$emit('change', e)
    }
  }
}
</script>
