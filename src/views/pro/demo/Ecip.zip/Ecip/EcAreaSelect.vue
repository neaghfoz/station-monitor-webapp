<template>

  <ec-tree-select
    v-model="areaId"
    title="区域选择"
    url="api/v1/sysrArea/data"
    :multiple="multiple"
    :is-post="false"
    :size="size"
    clearable
    @change="onChange"
  />

</template>

<script>

import EcTreeSelect from './EcTreeSelect'

export default {
  name: 'EcAreaSelect',
  components: { EcTreeSelect },
  // 2.2新增 在组件内定义 指定父组件调用时候的传值属性和事件类型
  model: {
    prop: 'value',
    event: 'change'
  },
  props: {
    value: {
      type: String,
      required: false
    },
    multiple: {
      type: Boolean,
      default: false
    },
    readOnly: {
      type: Boolean,
      default: false,
      required: false
    },
    size: {
      type: String,
      default: '',
      required: false
    }
  },
  data() {
    return {
      areaId: this.value || ''
    }
  },
  watch: {
    value(val) {
      this.areaId = val || ''
    }
  },
  methods: {
    onChange(e) {
      this.$emit('change', this.multiple ? e.join() : e)
    }
  }
}
</script>
