<template>

  <el-checkbox-group v-model="checkData" :size="size">
    <el-checkbox
      v-for="item in ecData || $dictUtils.getDictList(dictType)"
      :key="item[props.value]"
      :label="item[props.value]"
      @change="onChange"
    >
      {{ item[props.label] }}
    </el-checkbox>
  </el-checkbox-group>

</template>

<script>

// import dictMixin from '@/utils/dict-mixin'

export default {
  name: 'EcCheckboxGroup',
  mixins: [],
  // 2.2新增 在组件内定义 指定父组件调用时候的传值属性和事件类型
  model: {
    prop: 'value',
    event: 'change'
  },
  props: {
    value: {
      type: String,
      required: false
    },
    dictType: {
      type: String,
      default: '',
      required: false
    },
    ecData: {
      type: Array,
      default: () => { return [] },
      required: false
    },
    size: {
      type: String,
      default: '',
      required: false
    },
    props: {
      type: Object,
      default: () => {
        return {
          key: 'value',
          label: 'label',
          value: 'value'
        }
      }
    }
  },
  data() {
    return {
      checkData: []
    }
  },
  watch: {
    value: {
      handler(val) {
        this.checkData = !val ? [] : val.toString().split(',')
      },
      immediate: true
    }
  },
  created() {
    // this.setDictList([`${this.dictType || ''}`])
  },
  methods: {
    onChange() {
      this.$emit('change', this.checkData.join(','))
    }
  }
}
</script>
