<template>
  <div>
    <el-cascader
      v-model="selectData"
      placeholder="省市区选择"
      :options="areaRootList"
      :size="options.size"
      :show-all-levels="options.showAllLevels"
      :collapse-tags="options.collapseTags"
      :separator="options.separator"
      :filterable="options.filterable"
      :filter-method="options.filterMethod"
      :debounce="options.debounce"
      :clearable="options.clearable"
      :disabled="options.disabled"
      :props="options.cascaderProps"
      @change="onChange"
    />
  </div>

</template>

<script>
import { getAreaTree } from '@/api/sysrRquest'
import { cloneDeep } from '@/utils'
import Vue from 'vue'
export default {
  name: 'EcCitySelect',
  // 2.2新增 在组件内定义 指定父组件调用时候的传值属性和事件类型
  model: {
    prop: 'value',
    event: 'change'
  },
  props: {
    value: {
      type: String,
      required: false
    },
    cascaderProps: {
      type: Object,
      default: () => {
        return {
          expandTrigger: 'click', // 次级菜单的展开方式  click / hover
          multiple: false,
          checkStrictly: false, // 是否严格的遵守父子节点不互相关联
          emitPath: true, // 在选中节点改变时，是否返回由该节点所在的各级菜单的值所组成的数组，若设置 false，则只返回该节点的值
          lazy: false, // 是否动态加载子节点，需与 lazyLoad 方法结合使用
          lazyLoad: () => {}, // 加载动态数据的方法，仅在 lazy 为 true 时有效; function(node, resolve)，node为当前点击的节点，resolve为数据加载完成的回调(必须调用)
          value: 'name', //	指定选项的值为选项对象的某个属性值
          label: 'name', //  指定选项标签为选项对象的某个属性值
          children: 'children', //	指定选项的子选项为选项对象的某个属性值
          disabled: 'disabled', //  指定选项的禁用为选项对象的某个属性值
          leaf: 'leaf' //  指定选项的叶子节点的标志位为选项对象的某个属性值
        }
      }
    },
    clearable: {
      type: Boolean,
      default: true,
      required: false
    },
    disabled: {
      type: Boolean,
      default: false,
      required: false
    },
    separator: {
      type: String,
      default: '/',
      required: false
    },
    filterable: {
      type: Boolean,
      default: true,
      required: false
    },
    filterMethod: {
      type: Function,
      default: () => {},
      required: false
    },
    showAllLevels: {
      type: Boolean,
      default: true,
      required: false
    },
    collapseTags: {
      type: Boolean,
      default: false,
      required: false
    },
    debounce: {
      type: Number,
      default: 300,
      required: false
    },
    size: {
      type: String,
      default: '',
      required: false
    },
    vxeMode: { // 是否为vxeMode使用类型场景, 默认为false
      type: Boolean,
      default: false,
      required: false
    },
    //  vxeParams vxe组件传递行和对应参数
    vxeParams: Object,
    renderOpts: Object
  },
  data() {
    return {
      options: {
        cascaderProps: {
          expandTrigger: 'click',
          multiple: false,
          checkStrictly: false,
          emitPath: true,
          lazy: false,
          lazyLoad: () => {},
          value: 'name',
          label: 'name',
          children: 'children',
          disabled: 'disabled',
          leaf: 'leaf'
        },
        clearable: true,
        disabled: false,
        separator: '/',
        filterable: true,
        filterMethod: () => {},
        showAllLevels: true,
        collapseTags: false,
        debounce: 300,
        size: 'mini'
      },

      loading: false,
      areaList: [], //  通过递归遍历，拿到每一个节点
      areaRootList: [], //  含有子节点的树集合
      selectData: [],
      row: null,
      column: null
    }
  },
  watch: {
    value: {
      handler(val) {
        if (val) {
          this.selectData = this.cascaderProps.multiple ? val.split(',').map(item => item.split('/')) : val.split('/')
        }
      },
      immediate: true
    },
    'cascaderProps.multiple': {
      handler(val) {
        this.options.cascaderProps.multiple = val === true
      },
      immediate: true
    }
  },
  created() {
    this.init()
  },
  methods: {
    init() {
      this.propsInitData()
      this.initData()
    },
    initData() {
      this.getData()

      if (this.vxeMode) {
        const { row, column } = this.vxeParams
        this.row = row
        this.column = column
        const val = row[column.property]
        if (val) {
          this.selectData = this.options.cascaderProps.multiple ? val.split(',').map(item => item.split('/')) : val.split('/')
        }
      }
    },
    propsInitData() {
      if (this.vxeMode) {
        const { props } = this.renderOpts
        cloneDeep(this.options, props)
      } else {
        const { $props } = this
        cloneDeep(this.options, $props)
      }
    },
    async getData() {
      this.loading = true
      const { data } = await getAreaTree()
      this.areaRootList = data
      // this.separateTreeData(data)
      this.loading = false
    },
    onChange(e) {
      const result = this.options.cascaderProps.multiple ? e.map(item => item.join('/')).join() : e.join('/')

      if (this.vxeMode) {
        const { row, column } = this
        if (!row[column.property]) {
          Vue.set(row, column.property, result)
        } else {
          row[column.property] = result
        }
      } else {
        this.$emit('change', result)
      }
    }
  }
}
</script>
