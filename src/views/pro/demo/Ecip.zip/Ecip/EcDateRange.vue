<template>
  <div>
    <el-date-picker
      v-model="rangeDatePicker"
      :size="size"
      :format="format"
      :value-format="valueFormat || format"
      :type="dateType"
      range-separator="至"
      :start-placeholder="startPlaceholder"
      :end-placeholder="endPlaceholder"
      @change="onChange"
    />
  </div>

</template>

<script>
import Vue from 'vue'

export default {
  name: 'EcDateRange',
  model: {
    name: 'value',
    event: 'change'
  },
  props: {
    value: {
      type: Object,
      required: true
    },
    dateType: {
      type: String,
      default: 'daterange',
      required: false
    },
    format: {
      type: String,
      default: 'yyyy-MM-dd',
      required: false
    },
    valueFormat: {
      type: String,
      required: false
    },
    startPlaceholder: {
      type: String,
      default: '开始时间',
      required: false
    },
    endPlaceholder: {
      type: String,
      default: '结束时间',
      required: false
    },
    beginKey: { //  开始时间字段
      type: String,
      required: true
    },
    endKey: { //  结束时间字段
      type: String,
      required: true
    },
    size: {
      type: String,
      default: '',
      required: false
    }
  },
  data() {
    return {
      rangeDatePicker: []
    }
  },
  watch: {
    beginKey: {
      handler(val) {
        if (this.value[val]) {
          this.rangeDatePicker[0] = this.value[val]
        }
      },
      immediate: true
    },
    endKey: {
      handler(val) {
        if (this.value[val]) {
          this.rangeDatePicker[1] = this.value[val]
        }
      },
      immediate: true
    },
    value: {
      handler(val) {
        this.rangeDatePicker = []

        if (val[this.beginKey]) {
          this.rangeDatePicker.push(val[this.beginKey])
          if (val[this.endKey]) {
            this.rangeDatePicker.push(val[this.endKey])
          }
        } else {
          if (val[this.endKey]) {
            this.rangeDatePicker.push(val[this.endKey])
            this.rangeDatePicker.push(val[this.endKey])
          }
        }
      },
      immediate: true,
      deep: true
    }
  },
  methods: {
    onChange(e) {
      const result = Object.assign({}, this.value)

      Vue.set(result, this.beginKey, this.rangeDatePicker[0])
      Vue.set(result, this.endKey, this.rangeDatePicker[1])
      this.$emit('change', result)

      // if (result[this.beginKey]) {
      //   result[this.beginKey] = this.rangeDatePicker[0]
      // } else {
      //   Vue.set(result, this.beginKey, this.rangeDatePicker[0])
      // }
      // if (result[this.endKey]) {
      //   result[this.endKey] = this.rangeDatePicker[1]
      // } else {
      //   Vue.set(result, this.endKey, this.rangeDatePicker[1])
      // }
      //
      // this.$emit('change', result)
    }
  }

}
</script>
