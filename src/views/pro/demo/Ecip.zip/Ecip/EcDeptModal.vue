<template>
  <div>
    <el-input
      :size="options.size"
      class="detail-grid-width"
      :value="dept.shortName"
      :placeholder="options.title"
      type="text"
      readonly
      @focus="visible = true"
    >
      <el-button slot="append" icon="el-icon-search" @click="visible = true" />
    </el-input>
    <el-dialog
      ref="deptModal"
      width="80%"
      :visible.sync="visible"
      :title="options.title"
      :append-to-body="!vxeMode"
      @opened="setDefaultChecked"
    >
      <el-form ref="searchForm" :model="queryParams" inline label-width="100px">
        <el-form-item label="租户" prop="tenantId">
          <ec-tenant v-model="queryParams.tenantId" clearable filterable />
        </el-form-item>
        <el-form-item label="系统" prop="appId">
          <ec-register-app v-model="queryParams.appId" clearable filterable default-first :tenant-id="queryParams.tenantId" @hasInit="getTreeData('init')" @change="getTreeData('change')" />
        </el-form-item>
        <el-form-item label="编码" prop="code">
          <el-input v-model="queryParams.code" type="text" placeholder="编码" />
        </el-form-item>
        <el-form-item label="名称" prop="name">
          <el-input v-model="queryParams.shortName" type="text" placeholder="名称" />
        </el-form-item>
        <el-form-item class="searchItem" :label-width="'50px'">
          <el-button type="primary" @click="getTreeData">查询</el-button>
          <el-button type="default" @click="handleReset">重置</el-button>
        </el-form-item>
      </el-form>

      <vxe-virtual-tree
        ref="vxe"
        row-key
        row-id="id"
        show-overflow
        show-header-overflow
        border
        highlight-hover-row
        max-height="1000"
        class="vxe-table-element"
        resizable
        sync-resize
        auto-resize
        :loading="loading"
        :columns="columns"
        :tree-config="{children: 'children'}"
        :data="gridData"
        :expand-config="{ expandAll: true }"
        :checkbox-config="{ checkStrictly: !checkStrictly, checkField: 'checked', halfField: 'indeterminate'}"
      >
        <!--使用 bottom 插槽-->
        <template v-slot:bottom>
          <div class="vxe-bottom-container">
            <el-checkbox v-model="checkStrictly">父子级联</el-checkbox>
          </div>
        </template>
      </vxe-virtual-tree>

      <div slot="footer">
        <el-button type="primary" @click="confirm">确定</el-button>
        <el-button type="default" @click="visible = false">关闭</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import { getDeptTree, findDeptByIds as findDataByIds } from '@/api/sysrRquest'
import { cloneDeep } from '@/utils'
import Vue from 'vue'

export default {
  name: 'EcDeptModal',
  components: {},
  model: {
    prop: 'value',
    event: 'change'
  },
  props: {
    value: {
      type: String, //  树选择id
      required: false
    },
    params: {
      type: Object,
      default: () => {},
      required: false
    },
    data: {
      type: Object,
      default: () => {},
      required: false
    },
    excludeId: {
      type: String,
      required: false
    },
    multiple: {
      type: Boolean,
      default: false,
      required: false
    },
    size: {
      type: String,
      default: '',
      required: false
    },
    attrName: {
      type: String,
      default: 'shortName',
      required: false
    },
    vxeMode: { // 是否为vxeMode使用类型场景, 默认为false
      type: Boolean,
      default: false,
      required: false
    },
    //  vxeParams vxe组件传递行和对应参数
    vxeParams: Object,
    renderOpts: Object
  },
  data() {
    return {
      options: {
        params: {},
        multiple: false,
        size: 'mini',
        attrName: 'shortName',
        excludeId: ''
      },
      visible: false,
      loading: false,
      checkStrictly: false,
      dept: { id: '', shortName: '' },
      gridData: [],
      columns: [
        { type: 'checkbox', width: 40, fixed: 'left', align: 'center' },
        { title: '名称', field: 'name', treeNode: true, minWidth: 180, showOverflow: true },
        { title: '编码', field: 'code', minWidth: 180, showOverflow: true },
        { title: '组织名称', field: 'shortName', minWidth: 180, showOverflow: true },
        { title: '组织全称', field: 'fullName', minWidth: 240, showOverflow: true },
        { title: '启用状态', field: 'statusText', minWidth: 180, showOverflow: true }
      ],
      queryParams: {}
    }
  },
  watch: {
    $props: {
      handler(val) {
        this.$nextTick(() => {
          this.propsInitData()
        })
      },
      deep: true
    },
    value: {
      handler(val) {
        if (val) {
          this.getDeptsByIds(val)
        }
      },
      immediate: true
    },
    'options.excludeId': {
      handler(val) {
        this.initModalData()
      },
      deep: true
    }
  },
  created() {
    this.init()
  },
  methods: {
    init() {
      this.propsInitData()
      this.initModalData()
    },
    propsInitData() {
      if (this.vxeMode) { //  vxe 调用组件时，根据传递的renderOpts，初始化data中的属性
        const { props } = this.renderOpts
        cloneDeep(this.options, props)
      } else {
        const { $props } = this
        cloneDeep(this.options, $props)
      }
    },
    initModalData() {
      this.getTreeData()
    },
    recursion(ids, selections, tree) {
      if (tree) {
        tree.forEach(item => {
          if (ids.includes(item.id)) {
            selections.push(item)
          }
          if (item.children && item.children.length > 0) {
            this.recursion(ids, selections, item.children)
          }
        })
      }
    },
    setDefaultChecked() {
      const selecteds = []
      let ids = []

      if (this.vxeMode) {
        const { row, column } = this.vxeParams
        this.row = row
        this.column = column
        if (row[column.property] && row[column.property].id) {
          ids = row[column.property].id.split(',')
        }
      } else {
        ids = this.value ? this.value.split(',') : []
      }
      this.recursion(ids, selecteds, this.gridData)
      this.$nextTick(() => {
        this.$refs.vxe.setCheckboxRow(selecteds, true)
      })
      if (selecteds.length !== 0) {
        const deptId = selecteds.map(item => item.id).join()
        const deptShortName = selecteds.map(item => item[this.options.attrName]).join()
        this.dept = { id: deptId, shortName: deptShortName }
      }
    },
    async getTreeData(type) {
      try {
        this.loading = true
        const { data } = await getDeptTree(Object.assign({}, { excludeId: this.options.excludeId }, this.options.queryParams),
          Object.assign({}, this.options.data, this.queryParams))
        this.gridData = data
        if (type === 'change') {
          this.setDefaultChecked()
        }
      } finally {
        this.loading = false
      }
    },
    async getDeptsByIds(ids) {
      if (ids && ids.length > 0) {
        // 根据传入id，查询已选用户
        const { data } = await findDataByIds(ids)
        const deptId = data.map(item => item.id).join()
        const deptShortName = data.map(item => item[this.options.attrName]).join()
        this.dept = { id: deptId, shortName: deptShortName }
      }
    },
    confirm() {
      const selecteds = this.$refs.vxe.getCheckboxRecords()
      if (selecteds.length === 0) {
        this.$notify.warning('至少选择一个组织')
        return
      }
      if (!this.options.multiple && selecteds.length > 1) {
        this.$notify.warning('只能选择一个组织')
        return
      }

      const deptId = selecteds.map(item => item.id).join()
      const deptShortName = selecteds.map(item => item[this.options.attrName]).join()
      this.dept = { id: deptId, shortName: deptShortName }
      if (this.vxeMode) {
        const { row, column } = this
        if (!row[column.property]) {
          Vue.set(row, column.property, this.dept)
        } else {
          row[column.property] = this.dept
        }
      } else {
        this.$emit('change', deptId)
      }
      this.visible = false
    },
    handleReset() {
      this.$refs.searchForm.resetFields()
      this.getTreeData()
    }
  }
}
</script>
