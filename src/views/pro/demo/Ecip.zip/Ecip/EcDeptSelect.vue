<template>
  <el-select-tree
    :value="deptId"
    :default-expand-all="options.defaultExpandAll"
    :multiple="options.multiple"
    :placeholder="options.placeholder"
    :disabled="options.disabled"
    :popover-min-width="200"
    :data="deptTrees"
    :props="options.props"
    :size="options.size"
    :default-expanded-keys="defaultExpandedKeys"
    :disabled-values="options.disabledValues"
    :check-strictly="options.checkStrictly"
    :clearable="options.clearable"
    :filterable="options.filterable"
    @change="onChange"
  />
</template>

<script>
import ElSelectTree from './ElSelectTree'
import { getDeptTree } from '@/api/sysrRquest'
import { cloneDeep } from '@/utils'
import Vue from 'vue'

export default {
  name: 'EcDeptSelect',
  components: { ElSelectTree },
  model: {
    prop: 'value',
    event: 'change'
  },
  props: {
    value: {
      type: [Number, String, Array],
      required: false
    },
    ecData: {
      type: Array,
      required: false
    },
    data: {
      type: Object,
      required: false
    },
    params: {
      type: Object,
      required: false
    },
    tenantId: {
      type: String,
      required: false
    },
    multiple: {
      type: Boolean,
      default: false,
      required: false
    },
    checkStrictly: {
      type: Boolean,
      default: false,
      required: false
    },
    disabled: {
      type: Boolean,
      default: false,
      required: false
    },
    disabledValues: {
      type: Array,
      required: false
    },
    defaultExpandAll: {
      type: Boolean,
      default: false,
      required: false
    },
    clearable: {
      type: Boolean,
      default: false,
      required: false
    },
    filterable: {
      type: Boolean,
      default: false,
      required: false
    },
    placeholder: {
      type: String,
      default: '请选择',
      required: false
    },
    defaultExpandedKeys: {
      type: Array,
      required: false
    },
    size: {
      type: String,
      required: false
    },
    banRoot: {
      type: Boolean,
      default: false,
      required: false
    },
    props: {
      type: Object,
      default: () => {
        return {
          value: 'id',
          label: 'shortName',
          children: 'children'
        }
      }
    },
    vxeMode: { // 是否为vxeMode使用类型场景, 默认为false
      type: Boolean,
      default: false,
      required: false
    },
    //  vxeParams vxe组件传递行和对应参数
    vxeParams: Object,
    renderOpts: Object
  },
  data() {
    return {
      deptId: this.multiple ? [] : '',
      deptTrees: [],
      options: {
        multiple: false,
        data: {
          tenantId: '',
          appId: ''
        },
        params: {
          excludeId: ''
        },
        tenantId: '',
        checkStrictly: false,
        disabled: false,
        defaultExpandAll: false,
        clearable: false,
        filterable: false,
        banRoot: false,
        size: 'mini',
        placeholder: '请选择',
        disabledValues: [],
        props: {
          value: 'id',
          label: 'shortName',
          children: 'children'
        }
      }
    }
  },
  watch: {
    $props: {
      handler(val) {
        this.propsInitData()
      },
      deep: true
    },
    ecData() {
      this.init()
    },
    'options.data': {
      handler(val) {
        this.getDeptTree()
      },
      deep: true
    },
    'options.params': {
      handler(val) {
        this.getDeptTree()
      },
      deep: true
    },
    'options.ecData': {
      handler(val) {
        this.init()
      },
      deep: true
    },
    row: {
      handler(val) {
        if (val && val[this.column.property]) {
          this.deptId = this.options.multiple ? val[this.column.property].toString().split(',') : val[this.column.property].toString()
        } else {
          this.treeId = this.options.multiple ? [] : ''
        }
      },
      immediate: true,
      deep: true
    },
    value: {
      handler(val) {
        if (val) {
          this.deptId = this.multiple ? val.toString().split(',') : val.toString()
        } else {
          this.deptId = this.multiple ? [] : ''
        }
      },
      immediate: true
    }
  },
  created() {
    this.init()
  },
  methods: {
    init() {
      this.propsInitData()
      this.getDeptTree()
    },
    async getDeptTree() {
      if (this.options.ecData) {
        this.deptTrees = this.options.ecData
      } else {
        const { data } = await getDeptTree(this.options.params, this.options.data)
        this.deptTrees = data
      }
      if (this.options.banRoot) {
        this.options.disabledValues = this.deptTrees.map(item => item.id)
      }
    },
    propsInitData() {
      if (this.vxeMode) { //  vxe 调用组件时，根据传递的renderOpts，初始化data中的属性
        const { props } = this.renderOpts
        cloneDeep(this.options, props)
      } else {
        const { $props } = this
        cloneDeep(this.options, $props)
      }
    },
    onChange(e) {
      const result = this.options.multiple ? e.join() : e

      if (this.vxeMode) {
        const { row, column } = this
        if (!row[column.property]) {
          Vue.set(row, column.property, result)
        } else {
          row[column.property] = result
        }
      } else {
        this.$emit('change', result)
      }
    }
  }

}
</script>

<style scoped>

</style>
