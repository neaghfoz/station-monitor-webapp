<template>
  <div>
    <el-input
      :size="options.size"
      class="detail-grid-width"
      :value="file.fileName"
      placeholder="文件选择"
      type="text"
      readonly
      @focus="visible = true"
    >
      <el-button slot="append" icon="el-icon-search" @click="visible = true" />
    </el-input>

    <el-dialog
      ref="fileModal"
      :visible.sync="visible"
      title="文件选择"
      width="800px"
      :append-to-body="!vxeMode"
      @opened="initModalData"
    >
      <el-upload
        ref="fileUpload"
        :action="options.action"
        :headers="options.headers"
        :data="options.data"
        :name="options.name"
        :multiple="options.multiple"
        :with-credentials="options.withCredentials"
        :show-file-list="false"
        :limit="options.limit"
        :accept="options.accept"
        :list-type="options.listType"
        :file-list="options.fileList"
        :disabled="options.disabled"
        :before-upload="beforeUpload"
        :on-success="onSuccess"
        :on-error="onError"
        :on-exceed="onExceed"
        :on-progress="onProgress"
        :on-preview="onPreview"
        :on-change="onChange"
        :on-remove="onRemove"
      >
        <el-button slot="trigger" icon="ios-cloud-upload-outline">选取文件</el-button>
      </el-upload>
      <div style="margin: 10px 0 10px 0" />
      <vxe-grid
        ref="uploadFileGrid"
        class="vxe-table-element"
        max-height="400"
        highlight-hover-row
        border
        resizable
        sync-resize
        auto-resize
        :loading="uploadLoading"
        :data="dataList"
        :columns="columns"
      >
        <template v-slot:fileName="{ row }">
          <template v-if="isPicture(row.name)">
            <img :src="`${row.url}${token}`" width="160" height="90">
          </template>
          <template v-else>
            <p>{{ row.name }}</p>
          </template>
        </template>
        <template v-slot:size="{ row }">
          <p>{{ sizeTransferToText(row.size) }}</p>
        </template>
        <template v-slot:status="{ row }">
          <template v-if="reloading">
            <p><i class="el-icon-loading" /> 正在上传中...</p>
          </template>
          <template v-else>
            <p>{{ fileUploadStatus(row.status) }}</p>
          </template>
        </template>
        <template v-slot:operation="{ row }">
          <div class="aclass">
            <el-button v-if="isPicture(row.name)" type="text" @click="preview(row)">预览</el-button>
            <el-button type="text" @click="clickDownLoad(row)">下载</el-button>
            <el-button type="text" @click="clickDel(row)">删除</el-button>
          </div>
        </template>
      </vxe-grid>

      <div slot="footer">
        <el-button type="primary" @click="confirm">确定</el-button>
        <el-button type="default" @click="visible = false">关闭</el-button>
      </div>
    </el-dialog>

    <el-dialog :visible.sync="previewVisible" title="预览">
      <img :src="previewPic && previewPic.url ? `${previewPic.url}${token}` : ''" style="width: 100%">
    </el-dialog>
  </div>
</template>

<script>

import { getToken } from '@/utils/auth'
import { cloneDeep } from '@/utils'
import { guid } from '@/utils/tableUtil'

export default {
  name: 'EcFileModal',
  model: {
    prop: 'value',
    event: 'change'
  },
  props: {
    value: {
      type: [String, Object],
      required: false
    },
    action: { //  上传的地址
      type: String,
      default: 'api/v1/system/uploadFile',
      required: false
    },
    headers: { //  设置上传的请求头部
      type: Object,
      default: () => {
        return {
          token: getToken()
        }
      },
      required: false
    },
    multiple: { //  是否支持多选文件
      type: Boolean,
      default: false,
      required: false
    },
    data: { //  上传时附带的额外参数
      type: Object,
      required: false
    },
    name: { //  上传的文件字段名
      type: String,
      default: 'file',
      required: false
    },
    withCredentials: { //  支持发送 cookie 凭证信息
      type: Boolean,
      default: false,
      required: false
    },
    limit: {
      type: Number,
      default: 10,
      required: false
    },
    drag: { //  是否启用拖拽上传
      type: Boolean,
      default: false,
      required: false
    },
    accept: { //  接受上传的文件类型（thumbnail-mode 模式下此参数无效）
      type: String,
      required: false
    },
    listType: { //  	文件列表的类型,text/picture/picture-card
      type: String,
      default: 'text',
      required: false
    },
    fileList: { //  上传的文件列表, 例如: [{name: 'food.jpg', url: 'https://xxx.cdn.com/xxx.jpg'}]
      type: Array,
      default: () => { return [] },
      required: false
    },
    vxeMode: { // 是否为vxeMode使用类型场景, 默认为false
      type: Boolean,
      default: false,
      required: false
    },
    //  vxeParams vxe组件传递行和对应参数
    vxeParams: Object,
    renderOpts: Object
  },
  data() {
    return {
      options: {
        action: 'api/v1/system/uploadFile',
        headers: { token: getToken() },
        multiple: false,
        data: Object,
        name: 'file',
        withCredentials: false,
        limit: 10,
        drag: false,
        accept: Object,
        listType: 'text',
        fileList: []
      },
      visible: false,
      uploadLoading: false,
      reloading: false,
      canUpload: false,
      token: `&token=${getToken()}`,
      file: { id: '', fileName: '' },
      previewVisible: false,
      previewPic: {},
      dataList: [],
      columns: [
        { title: '文件', field: 'name', minWith: 180, showOverflow: true, slots: { default: 'fileName' }},
        { title: '文件大小', field: 'size', minWith: 120, showOverflow: true, slots: { default: 'size' }},
        { title: '状态', field: 'status', minWith: 120, showOverflow: true, slots: { default: 'status' }},
        { title: '操作', width: 180, fixed: 'right', align: 'center', slots: { default: 'operation' }}
      ]
    }
  },
  watch: {

  },
  created() {
    this.propsInitData()
  },
  methods: {
    init() {

    },
    initModalData() {

    },
    propsInitData() {
      if (this.vxeMode) {
        const { props } = this.renderOpts
        cloneDeep(this.options, props)
      } else {
        const { $props } = this
        cloneDeep(this.options, $props)
      }
    },
    async getFileByIds() {
      // const { data } = await {}
    },
    beforeUpload(file, fileList) {
    },
    onSuccess(resp, file, filelist) {
      if (!resp.success) {
        this.onError(resp, file, filelist)
        return
      }
      const data = resp.data
      data.status = 'success'
      data._id = data.id
      this.dataList.push(data)
      this.$notify.success('文件上传成功!')
    },
    onError(e, file, filelist) {
      file._id = guid()
      this.$notify.error('文件上传失败!')
    },
    onProgress() {
    },
    onChange(file, fileList) {
    },
    onRemove(file, fileList) {
    },
    onPreview(file, fileList) {
    },
    onExceed(files, fileList) {
      this.$notify.warning(`限制选择 ${this.options.limit} 个文件`)
    },
    uploadFiles() { //  手动上传文件
      const files = this.$refs.fileUpload.uploadFiles
      const readyList = files.filter(item => item.status === 'ready')
      // const reuploadList = files.filter(item => item.status !== 'ready')
      if (readyList.length > 0) {
        this.uploadLoading = true
        this.$refs.fileUpload.submit()
      }
    },
    clickDownLoad(row) { // todo
      window.open(`${row.url}?download=true${this.token}`)
    },
    preview(row) {
      this.previewVisible = true
      this.previewPic = row
    },
    clickDel(row) {
      this.dataList = this.dataList.filter(item => item._id !== row._id)
    },
    sizeTransferToText(size) {
      if (typeof size === 'number') {
        return size + 'B'
      } else {
        return size
      }
    },
    fileUploadStatus(status) {
      if (status === 'ready') {
        return '未上传'
      } else if (status === 'success') {
        return '上传成功'
      } else if (status === 'uploaded') {
        return '已上传'
      } else {
        return '上传失败'
      }
    },
    isPicture(filename) {
      if (!filename) {
        return false
      }
      const a = filename.split('').reverse().join('')
      const suffix = a.substring(0, a.search(/\./)).split('').reverse().join('').toLowerCase()
      return suffix === 'jpg' || suffix === 'jpeg' || suffix === 'png'
    },
    confirm() {
      const result = this.dataList.filter(item => {
        if (item.status === 'uploaded' || item.status === 'success') {
          return item
        }
      })

      const fileId = result.map(item => item.id).join()
      const fileName = result.map(item => item.name).join()

      this.file = { id: fileId, fileName: fileName }

      this.$emit('change', fileId)
      this.visible = false
    }
  }
}
</script>
