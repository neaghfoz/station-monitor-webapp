<template>

  <el-input
    v-if="object"
    class="detail-grid-width"
    :value="object[fieldName] && object[fieldName].fileName"
    placeholder="文件选择"
    :size="size"
    type="text"
    readonly
    @focus="fileSelectPlus(object, fieldName, Object.assign({}, { multiple: multiple }, params || {}), fileChange)"
  />
  <el-input v-else :size="size" class="detail-grid-width" :value="file.fileName" placeholder="文件选择" type="text" readonly @focus="fileSelect(file, multiple, fileChange, params)" />

</template>

<script>
import { fileSelect, fileSelectPlus } from '../SelectDialog'
import { findFileByIds } from '@/api/sysrRquest'

export default {
  name: 'EcFileSelect',
  model: {
    prop: 'value',
    event: 'change'
  },
  props: {
    value: {
      type: [String, Object]
    },
    object: {
      type: Object
    },
    fieldName: {
      type: String
    },
    size: {
      type: String,
      default: '',
      required: false
    },
    multiple: {
      type: Boolean,
      default: false
    },
    params: {
      type: Object
    }
  },
  data() {
    return {
      file: { id: '', fileName: '' }
    }
  },
  watch: {
    async value(val) {
      if (val) {
        if (typeof val === 'string') {
          const { data } = await findFileByIds(val)
          const fileId = data.map(item => item.id).join()
          const fileName = data.map(item => item.fileName).join()
          this.file = { id: fileId, fileName: fileName }
        } else if (typeof val === 'object') {
          this.file = val
        }
      } else {
        this.file = { id: '', fileName: '' }
      }
    }
  },
  methods: {
    fileSelect,
    fileSelectPlus,
    fileChange(e) {
      this.$emit('change', e && e.id)
    }
  }
}
</script>

<style scoped>

</style>
