<template>
  <div>
    <!--grid选择input框-->
    <el-input
      :size="options.size"
      class="detail-grid-width"
      :value="grid.name"
      :placeholder="`${options.title}选择`"
      type="text"
      readonly
      @focus="visible = true"
    >
      <el-button slot="append" icon="el-icon-search" @click="visible = true" />
    </el-input>

    <el-dialog
      ref="gridModal"
      :visible.sync="visible"
      :title="options.title"
      width="1400px"
      :append-to-body="!vxeMode"
      @opened="initModalData"
    >
      <el-row type="flex" :gutter="8" justify="center">
        <el-col class="table-page-wrapper" :span="20">
          <div class="table-search-form">
            <el-form ref="search" :model="search" inline>
              <el-form-item
                v-for="(label, key) in searchOpts"
                :key="key"
                :label="label"
                :prop="key"
                :label-width="'100px'"
              >
                <el-input v-model="search[key]" type="text" :placeholder="label" />
              </el-form-item>
              <el-form-item class="searchItem" :label-width="'50px'">
                <el-button type="primary" @click="getGridData">查询</el-button>
                <el-button type="default" @click="resetSearchForm">重置</el-button>
              </el-form-item>
            </el-form>
          </div>

          <vxe-grid
            ref="gridVxeTables"
            highlight-hover-row
            border
            resizable
            auto-resize
            sync-resize
            class="vxe-table-element"
            :loading="loading"
            :start-index="(page.currentPage - 1) * page.pageSize"
            :pager-config="page"
            :columns="columns"
            :data="gridData"
            :checkbox-config="{checkStrictly: !options.multiple}"
            @page-change="handlePageChange"
            @checkbox-all="({ selection }) => { selections = selection }"
            @checkbox-change="({ selection }) => { selections = selection }"
          />
        </el-col>
      </el-row>
      <div slot="footer">
        <el-button type="primary" @click="confirm">确定</el-button>
        <el-button type="default" @click="visible = false">关闭</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>

import Vue from 'vue'
import { findGridByIds, getGridData } from '@/api/sysrRquest'

export default {
  name: 'EcGridModal',
  model: {
    prop: 'value',
    event: 'change'
  },
  props: {
    value: {
      type: [String, Object],
      required: false
    },
    url: {
      type: String,
      required: false
    },
    fieldKeys: {
      type: String,
      required: false
    },
    fieldLabels: {
      type: String,
      required: false
    },
    searchFields: {
      type: String,
      required: false
    },
    searchLabels: {
      type: String,
      required: false
    },
    title: {
      type: String,
      default: 'GRID选择',
      required: false
    },
    multiple: {
      type: Boolean,
      default: false,
      required: false
    },
    params: {
      type: Object,
      default: () => {},
      required: false
    },
    attrName: {
      type: String,
      default: 'name',
      required: false
    },
    size: {
      type: String,
      default: '',
      required: false
    },
    vxeMode: { // 是否为vxeMode使用类型场景, 默认为false
      type: Boolean,
      default: false,
      required: false
    },
    //  vxeParams vxe组件传递行和对应参数
    vxeParams: Object,
    renderOpts: Object
  },
  data() {
    return {
      options: {
        url: '',
        idsUrl: '',
        fieldKeys: '',
        fieldLabels: '',
        searchFields: '',
        searchLabels: '',
        title: 'GRID选择',
        multiple: false,
        params: {},
        attrName: 'name',
        size: 'mini'
      },
      loading: false,
      visible: false,
      search: {},
      // searchFields、searchLabels 转换后处理成为 searchOpts: { field: label }
      searchOpts: {},
      page: {
        total: 0,
        currentPage: 1,
        pageSize: 10,
        align: 'left',
        pageSizes: [10, 20, 50, 100, 200, 500],
        layouts: ['Sizes', 'PrevJump', 'PrevPage', 'Number', 'NextPage', 'NextJump', 'FullJump', 'Total'],
        perfect: true
      },
      columns: [],
      selections: [],
      selecteds: [],
      gridData: [],
      grid: { id: '', name: '' }
    }
  },
  watch: {
    value: {
      handler(val) {
        if (val) {
          this.getDataByIds(val)
        } else {
          this.user = { id: '', realName: '' }
        }
      },
      immediate: true
    }
  },
  created() {
    this.init()
  },
  methods: {
    init() {
      this.propsInitData()

      if (this.vxeMode) {
        const { row, column } = this.vxeParams
        this.row = row
        this.column = column
        if (row[column.property] && row[column.property].id) {
          this.getDataByIds(row[column.property].id)
        }
      } else { //  todo 暂时这样处理普通调用
        this.getDataByIds(this.value)
      }
    },
    initData() {
      this.search = {}
      this.gridData = []
      // 初始化已选
      this.selections = []
      this.page = {
        total: 0,
        currentPage: 1,
        pageSize: 10,
        align: 'left',
        pageSizes: [10, 20, 50, 100, 200, 500],
        layouts: ['Sizes', 'PrevJump', 'PrevPage', 'Number', 'NextPage', 'NextJump', 'FullJump', 'Total'],
        perfect: true
      }
    },
    initModalData() {
      this.propsInitData()
      this.initData()
      this.selections = this.selecteds
      this.getGridData()
    },
    propsInitData() {
      if (this.vxeMode) { //  vxe 调用组件时，根据传递的renderOpts，初始化data中的属性
        const { props } = this.renderOpts
        Object.assign(this.options, props)
        if (props.url) { //  html 直接调用组件时，根据传递的props参数初始化data中的属性
          this.options.idsUrl = props.url.replace('/data', '/findDataByIds')
        }
      } else {
        const { $props } = this
        Object.assign(this.options, $props)
      }
      this.searchOpts = this.fieldsHandle(this.options.searchFields, this.options.searchLabels, 'search')
      this.columns = this.fieldsHandle(this.options.fieldKeys, this.options.fieldLabels, 'column')
      this.columns.splice(0, 0, { type: 'checkbox', width: 40, fixed: 'left', align: 'center' })
    },
    fieldsHandle(keysStr, labelsStr, type) {
      const result = type === 'column' ? [] : {}
      if (keysStr && labelsStr) {
        const keys = keysStr.split('|')
        const labels = labelsStr.split('|')
        if (keys.length !== labels.length) {
          throw new Error('keys 和 labels 个数不对应!')
        }
        for (let i = 0; i < keys.length; i++) {
          if (type === 'column') {
            const temp = { title: labels[i], field: keys[i], minWith: 120, showOverflow: true }
            result.push(temp)
          } else {
            Vue.set(result, keys[i], labels[i])
          }
        }
      }
      return result
    },
    async getDataByIds(ids) {
      if (!this.vxeMode) {
        this.options.idsUrl = this.url.lastIndexOf('/data') !== -1 ? this.url.replace('/data', '/findDataByIds') : this.url.concat('/findDataByIds')
      }
      if (ids && ids.length > 0) {
        const { data } = await findGridByIds(this.options.idsUrl, ids)
        const gridId = data.map(item => item.id).join()
        const gridName = data.map(item => item[this.attrName]).join()
        this.selections = data
        this.selecteds = data
        this.grid = { id: gridId, name: gridName }
      }
    },
    async getGridData() {
      const { data } = await getGridData(this.options.url,
        Object.assign({}, { size: this.page.pageSize, current: this.page.currentPage }),
        Object.assign({}, this.options.params, this.search))
      this.gridData = data.records
      this.page.total = data.total
      const gridIds = this.selecteds.map(item => item.id).join()
      this.loading = false
      this.$nextTick(() => {
        this.gridData.filter(item => {
          if (gridIds.indexOf(item.id) !== -1) {
            return item
          }
        }).forEach(row => {
          this.$refs.gridVxeTables.setCheckboxRow(row, true)
        })
      })
    },
    resetSearchForm() {
      this.$refs.searchForm.resetFields()
      this.getGridData()
    },
    handlePageChange({ currentPage, pageSize }) {
      this.page.currentPage = currentPage
      this.page.pageSize = pageSize
      this.getGridData()
    },
    confirm() {
      if (this.selections === 0) {
        this.$notify.warning('至少选择一条数据')
        return
      }
      if (!this.options.multiple && this.selections.length > 1) {
        this.$notify.warning('只能选择一条数据')
        return
      }
      this.selecteds = this.selections

      const gridId = this.selections.map(item => item.id).join()
      const gridName = this.selections.map(item => item[this.options.attrName]).join()
      this.grid = { id: gridId, name: gridName }
      if (this.vxeMode) {
        const { row, column } = this
        if (!row[column.property]) {
          Vue.set(row, column.property, this.grid)
        } else {
          row[column.property] = this.user
        }
      } else {
        this.$emit('change', gridId)
      }
      // this.$emit('on-close', this.selections.map(item => { return { id: item.id, realName: item.realName } }))
      this.visible = false
    }
  }
}
</script>
