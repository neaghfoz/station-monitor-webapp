<template>
  <el-input
    v-if="object"
    class="detail-grid-width"
    :value="gridItem.name"
    :placeholder="title"
    :size="size"
    type="text"
    readonly
    @focus="gridSelectPlus(object, fieldName, title, url, fieldKeys, fieldLabels, searchKeys, searchLabels,
                           Object.assign({}, { multiple: multiple }, params || {}), gridChange)"
  />
  <el-input
    v-else
    class="detail-grid-width"
    :value="gridItem.name"
    :placeholder="title"
    type="text"
    :size="size"
    readonly
    @focus="gridSelect(gridItem, title, url, fieldKeys, fieldLabels, searchKeys, searchLabels, multiple, gridChange, params)"
  />

</template>

<script>
import { gridSelect, gridSelectPlus } from '../SelectDialog'
import { findGridByIds } from '@/api/sysrRquest'

export default {
  name: 'EcGridSelect',
  model: {
    prop: 'value',
    event: 'change'
  },
  props: {
    value: {
      type: [String, Object] // grid id/ids
    },
    object: {
      type: Object
    },
    fieldName: {
      type: String
    },
    url: {
      type: String,
      default: ''
    },
    fieldKeys: {
      type: String,
      default: ''
    },
    fieldLabels: {
      type: String,
      default: ''
    },
    searchKeys: {
      type: String,
      default: ''
    },
    searchLabels: {
      type: String,
      default: ''
    },
    params: Object,
    title: {
      type: String,
      default: 'Grid选择'
    },
    multiple: {
      type: Boolean,
      default: false
    },
    size: {
      type: String,
      default: '',
      required: false
    }
  },
  data() {
    return {
      gridItem: { id: '', name: '' }
    }
  },
  watch: {
    async value(val) {
      if (val) {
        if (typeof val === 'string') {
          const { data } = await findGridByIds(val)
          const gridId = data.map(item => item.id).join()
          const gridName = data.map(item => item.name).join()
          this.gridItem = { id: gridId, name: gridName }
        } else if (typeof val === 'object') {
          this.gridItem = val
        }
      } else {
        this.gridItem = { id: '', name: '' }
      }
    }
  },
  methods: {
    gridSelect,
    gridSelectPlus,
    gridChange(e) {
      this.$emit('change', e && e.id)
    }
  }
}
</script>

<style scoped>

</style>
