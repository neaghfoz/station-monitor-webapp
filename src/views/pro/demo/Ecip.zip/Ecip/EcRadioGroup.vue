<template>
  <el-radio-group v-model="chooseData" :size="size" @change="onChange">
    <el-radio
      v-for="item in ecData || $dictUtils.getDictList(dictType)"
      :key="item.value"
      :label="item.value"
    >
      {{ item.label }}
    </el-radio>
  </el-radio-group>
</template>

<script>

// import dictMixin from '@/utils/dict-mixin'

export default {
  name: 'EcRadioGroup',
  mixins: [],
  // 2.2新增 在组件内定义 指定父组件调用时候的传值属性和事件类型
  model: {
    prop: 'value',
    event: 'change'
  },
  props: {
    value: {
      type: [String, Number, Boolean],
      required: false
    },
    ecData: {
      type: Array,
      required: false
    },
    dictType: {
      type: String,
      default: '',
      required: false
    },
    size: {
      type: String,
      default: '',
      required: false
    }
  },
  data() {
    return {
      chooseData: this.value
    }
  },
  watch: {
    value(val) {
      this.chooseData = val
    }
  },
  created() {
    // this.setDictList([`${this.dictType || ''}`])
  },
  methods: {
    onChange(e) {
      this.$emit('change', e)
    }
  }
}
</script>
