<template>
  <el-select
    :value="appId"
    :multiple="options.multiple"
    :size="options.size"
    :clearable="options.clearable"
    :filterable="options.filterable"
    :disabled="options.disabled"
    placeholder="请选择系统"
    @change="onChange"
  >
    <el-option
      v-for="item in appList"
      :key="item.appId"
      :label="item.appName"
      :value="item.appId"
    />
  </el-select>
</template>

<script>

import { findAppListByTenant } from '@/api/sysrRquest'
import Vue from 'vue'
import { cloneDeep } from '@/utils'

export default {
  name: 'EcRegisterApp',
  components: {},
  // 2.2新增 在组件内定义 指定父组件调用时候的传值属性和事件类型
  model: {
    prop: 'value',
    event: 'change'
  },
  props: {
    value: {
      type: [String, Number],
      required: false
    },
    tenantId: {
      type: String,
      required: false
    },
    defaultFirst: {
      type: Boolean,
      default: false,
      required: false
    },
    multiple: {
      type: Boolean,
      default: false,
      required: false
    },
    disabled: {
      type: Boolean,
      default: false,
      required: false
    },
    clearable: {
      type: Boolean,
      default: true,
      required: false
    },
    filterable: {
      type: Boolean,
      default: false,
      required: false
    },
    size: {
      type: String,
      default: '',
      required: false
    },
    vxeMode: { // 是否为vxeMode使用类型场景, 默认为false
      type: Boolean,
      default: false,
      required: false
    },
    //  vxeParams vxe组件传递行和对应参数
    vxeParams: Object,
    renderOpts: Object
  },
  data() {
    return {
      options: {
        tenantId: null,
        defaultFirst: false,
        multiple: false,
        filterable: true,
        clearable: true,
        disabled: false,
        size: 'mini'
      },
      appId: null,
      appList: [],
      row: null,
      column: null
    }
  },
  watch: {
    $props: {
      handler(val) {
        this.$nextTick(() => {
          this.propsInitData()
        })
      },
      deep: true
    },
    row: {
      handler(val) {
        if (val) {
          this.appId = this.options.multiple ? val[this.column.property].split(',').map(id => parseInt(id)) : parseInt(val[this.column.property])
        } else {
          this.appId = null
        }
      },
      deep: true
    },
    value: {
      handler(val) {
        if (val) {
          this.appId = this.options.multiple ? val.split(',').map(id => parseInt(id)) : parseInt(val)
        } else {
          this.appId = null
        }
      },
      immediate: true
    },
    tenantId: {
      handler(val) {
        this.getAppList(val)
      }
    }
  },
  created() {
    this.init()
  },
  methods: {
    init() {
      this.$nextTick(async() => {
        this.propsInitData()
        this.initData()
        await this.getAppList(this.options.tenantId)
        this.$emit('hasInit', true)
      })
    },
    initData() {
      if (this.vxeMode) {
        const { row, column } = this.vxeParams
        this.row = row
        this.column = column
      }
    },
    propsInitData() {
      if (this.vxeMode) { //  vxe 调用组件时，根据传递的renderOpts，初始化data中的属性
        const { props } = this.renderOpts
        cloneDeep(this.options, props)
      } else {
        const { $props } = this
        cloneDeep(this.options, $props)
      }
    },
    async getAppList(tenantId) {
      const { data } = await findAppListByTenant(tenantId)
      this.appList = data
      if (this.options.defaultFirst && data.length > 0) {
        this.appId = data[0].appId
      }
      this.$emit('change', this.appId || '')
    },
    onChange(e) {
      const result = this.options.multiple ? e.join() : e

      if (this.vxeMode) {
        const { row, column } = this
        if (!row[column.property]) {
          Vue.set(row, column.property, result)
        } else {
          row[column.property] = result
        }
      } else {
        this.$emit('change', result)
      }
    }
  }
}
</script>
