<template>
  <div class="ec-select">
    <el-select
      :value="selected"
      :multiple="options.multiple"
      :size="options.size"
      :clearable="options.clearable"
      @change="onChange"
    >
      <el-option
        v-for="item in options.ecData || $dictUtils.getDictList(dictType)"
        :key="item[options.selectProps.value]"
        :value="item[options.selectProps.value]"
        :label="item[options.selectProps.label]"
      />
    </el-select>
  </div>
</template>

<script>

// import dictMixin from '@/utils/dict-mixin'
import Vue from 'vue'

export default {
  name: 'EcSelect',
  components: {},
  mixins: [],
  // 2.2新增 在组件内定义 指定父组件调用时候的传值属性和事件类型
  model: {
    prop: 'value',
    event: 'change'
  },
  props: {
    value: {
      type: [String, Number, Boolean],
      required: false
    },
    ecData: { // 传递数值数组
      type: Array,
      required: false
    },
    dictType: { //  传递数据字典类型
      type: String,
      required: false
    },
    selectProps: {
      type: Object,
      default: () => {
        return {
          value: 'value',
          key: 'value',
          label: 'label'
        }
      },
      required: false
    },
    multiple: {
      type: Boolean,
      default: false,
      required: false
    },
    clearable: {
      type: Boolean,
      default: true,
      required: false
    },
    size: {
      type: String,
      default: '',
      required: false
    },
    vxeMode: { // 是否为vxeMode使用类型场景, 默认为false
      type: Boolean,
      default: false,
      required: false
    },
    //  vxeParams vxe组件传递行和对应参数
    vxeParams: Object,
    renderOpts: Object
  },
  data() {
    return {
      options: {
        dictType: '',
        multiple: false,
        clearable: true,
        size: 'mini',
        selectProps: {
          value: 'value',
          key: 'value',
          label: 'label'
        }
      },
      // selectOpts: [],
      selected: null,
      row: null,
      column: null
    }
  },
  watch: {
    'options.multiple': {
      handler(multiple) {
        this.selected = multiple ? [] : ''
      },
      deep: true,
      immediate: true
    },
    multiple: {
      handler(multiple) {
        this.options.multiple = multiple === true
        if (this.options.multiple) {
          this.selected = !this.value ? [] : this.value.split(',')
        } else {
          this.selected = this.value || ''
        }
      },
      immediate: true
    },
    row: {
      handler(val) {
        if (val && val[this.column.property]) {
          this.selected = this.options.multiple ? val[this.column.property].toString().split(',') : val[this.column.property].toString()
        } else {
          this.selected = this.options.multiple ? [] : ''
        }
      },
      immediate: true,
      deep: true
    },
    value: {
      handler(val) {
        if (val) {
          this.selected = this.multiple ? val.toString().split(',') : val.toString()
        } else {
          this.selected = this.multiple ? [] : ''
        }
      },
      immediate: true
    }
  },
  created() {
    this.init()
  },
  methods: {
    init() {
      this.$nextTick(() => {
        this.propsInitData()
        this.initData()
      })
    },
    initData() {
      // this.setDictList([`${this.options.dictType || ''}`])
      // this.selectOpts = this.dictList[this.options.dictType] || this.options.ecData

      if (this.vxeMode) {
        const { row, column } = this.vxeParams
        this.row = row
        this.column = column
        // const val = row[column.property]
        // if (val) {
        //   this.selected = this.options.multiple ? val.toString().split(',') : val
        // } else {
        //   this.selected = this.options.multiple ? [] : ''
        // }
      }
      // else {
      //   if (this.value) {
      //     this.selected = this.options.multiple ? this.value.toString().split(',') : this.value.toString()
      //
      //   }
      //   if (this.options.multiple) {
      //     this.selected = !this.value ? [] : this.value.split(',')
      //   } else {
      //     this.selected = this.value || ''
      //   }
      // }
    },
    propsInitData() {
      if (this.vxeMode) { //  vxe 调用组件时，根据传递的renderOpts，初始化data中的属性
        const { props } = this.renderOpts
        Object.assign(this.options, props)
      } else {
        const { $props } = this
        Object.assign(this.options, $props)
      }
    },
    onChange(e) {
      const result = this.options.multiple ? e.join() : e

      if (this.vxeMode) {
        const { row, column } = this
        if (!row[column.property]) {
          Vue.set(row, column.property, result)
        } else {
          row[column.property] = result
        }
      } else {
        this.$emit('change', result)
      }
    }
  }
}
</script>

<style lang="scss" scoped>
  .ec-select >>> .el-select {
    display: block;
  }
</style>

