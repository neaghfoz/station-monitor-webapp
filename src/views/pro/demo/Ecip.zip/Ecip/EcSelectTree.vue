<template>
  <el-select-tree
    ref="elSelectTree"
    :value="treeId"
    :default-expand-all="options.defaultExpandAll"
    :multiple="options.multiple"
    :placeholder="options.placeholder"
    :disabled="options.disabled"
    :popover-min-width="200"
    :data="treeData"
    :props="options.props"
    :size="options.size"
    :default-expanded-keys="defaultExpandedKeys"
    :disabled-values="options.disabledValues"
    :check-strictly="options.checkStrictly"
    :clearable="options.clearable"
    :filterable="options.filterable"
    @change="onChange"
  />
</template>

<script>
/**
   * vxe-grid 每次编辑时，都会调取created钩子，所以vxe相关初始化应该在created钩子中进行；
   * 外部普通使用组件的时候，只有进入编辑页面第一次会执行created，后续重复点击modal都不会进入created钩子，故初始化需要放在dialog弹框弹出的时候执行；
   */
import { getTreeData } from '@/api/sysrRquest'

import Vue from 'vue'
import { cloneDeep } from '@/utils'

export default {
  name: 'EcSelectTree',
  model: {
    prop: 'value',
    event: 'change'
  },
  props: { //  后续再props新增接收属性，都需要在data中新增对应tm+属性名的对应映射的属性，并在propsInitData、vxeInitData中初始化
    value: {
      type: [Number, String, Array],
      required: false
    },
    url: {
      type: String,
      required: false
    },
    ecData: {
      type: Array,
      required: false
    },
    data: {
      type: Object,
      default: () => {},
      required: false
    },
    params: {
      type: Object,
      default: () => {},
      required: false
    },
    multiple: {
      type: Boolean,
      default: false,
      required: false
    },
    checkStrictly: {
      type: Boolean,
      default: true,
      required: false
    },
    disabled: {
      type: Boolean,
      default: false,
      required: false
    },
    disabledValues: {
      type: Array,
      required: false
    },
    defaultExpandAll: {
      type: Boolean,
      default: false,
      required: false
    },
    clearable: {
      type: Boolean,
      default: true,
      required: false
    },
    filterable: {
      type: Boolean,
      default: true,
      required: false
    },
    placeholder: {
      type: String,
      default: '请选择',
      required: false
    },
    defaultExpandedKeys: {
      type: Array,
      required: false
    },
    size: {
      type: String,
      required: false
    },
    banRoot: {
      type: Boolean,
      default: false,
      required: false
    },
    props: {
      type: Object,
      default: () => {
        return {
          value: 'id',
          label: 'name',
          children: 'children'
        }
      }
    },
    vxeMode: { // 是否为vxeMode使用类型场景, 默认为false
      type: Boolean,
      default: false,
      required: false
    },
    //  vxeParams vxe组件传递行和对应参数
    vxeParams: Object,
    renderOpts: Object,
    nodeKey: {
      type: String,
      default: 'id',
      required: false
    },
    isPost: {
      type: Boolean,
      default: true,
      required: false
    },
    attrName: {
      type: String,
      default: 'name',
      required: false
    },
    defaultProps: {
      type: Object,
      default: () => {
        return {
          children: 'children',
          label: 'name'
        }
      }
    }
  },
  data() {
    return {
      treeId: this.multiple ? [] : '',
      options: { // 以上为data属性对应 props属性
        url: '',
        data: {
          tenantId: '',
          appId: ''
        },
        params: {
          excludeId: ''
        },
        isPost: true,
        nodeKey: 'id',
        defaultProps: {
          children: 'children',
          label: 'name'
        },
        multiple: false,
        tenantId: '',
        checkStrictly: true,
        disabled: false,
        defaultExpandAll: false,
        clearable: true,
        filterable: true,
        banRoot: false,
        size: 'mini',
        placeholder: '请选择',
        disabledValues: [],
        props: {
          value: 'id',
          label: 'shortName',
          children: 'children'
        }
      },
      treeData: [],
      row: null,
      column: null
    }
  },
  watch: {
    $props: {
      handler(val) {
        this.$nextTick(() => {
          this.propsInitData()
        })
      },
      deep: true
    },
    'options.data': {
      handler(val) {
        this.initModalData()
      },
      deep: true
    },
    'options.params': {
      handler(val) {
        this.initModalData()
      },
      deep: true
    },
    row: {
      handler(val) {
        if (val && val[this.column.property]) {
          this.treeId = this.options.multiple ? val[this.column.property].toString().split(',') : val[this.column.property].toString()
        } else {
          this.treeId = this.options.multiple ? [] : ''
        }
      },
      immediate: true,
      deep: true
    },
    value: {
      handler(val) {
        if (val) {
          this.treeId = this.multiple ? val.toString().split(',') : val.toString()
        } else {
          this.treeId = this.multiple ? [] : ''
        }
      },
      immediate: true
    }
  },
  created() {
    this.init()
  },
  methods: {
    async init() {
      this.$nextTick(() => {
        this.propsInitData()
        this.initModalData()
      })
    },
    initData() {
      // 初始化
      this.propsInitData()
    },
    async initModalData() {
      await this.getTreeData()
    },
    propsInitData() {
      if (this.vxeMode) { //  vxe 调用组件时，根据传递的renderOpts，初始化data中的属性
        const { props } = this.renderOpts
        cloneDeep(this.options, props)
      } else {
        const { $props } = this
        cloneDeep(this.options, $props)
      }
    },
    async getTreeData() {
      const { data } = await getTreeData(this.options.url, Object.assign({}, { excludeId: this.options.excludeId },
        this.options.params), this.options.data, this.options.isPost)
      this.treeData = data
    },
    onChange(e) {
      const result = this.options.multiple ? e.join() : e

      if (this.vxeMode) {
        const { row, column } = this
        if (!row[column.property]) {
          Vue.set(row, column.property, result)
        } else {
          row[column.property] = result
        }
      } else {
        this.$emit('change', result, this.options.multiple ? this.$refs.elSelectTree.getCheckedNodes() : this.$refs.elSelectTree.getCurrentNode())
      }
    }
  }
}
</script>
