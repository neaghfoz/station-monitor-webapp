<template>
  <el-select
    :value="tenantId"
    :multiple="options.multiple"
    :size="options.size"
    :clearable="options.clearable"
    :filterable="options.filterable"
    placeholder="请选择租户"
    @change="onChange"
  >
    <el-option
      v-for="item in tenantList"
      :key="item.id"
      :label="item.name"
      :value="item.id"
    />
  </el-select>
</template>

<script>

import { findTenantList } from '@/api/sysrRquest'
import Vue from 'vue'
import { cloneDeep } from '@/utils'

export default {
  name: 'EcTenant',
  components: {},
  // 2.2新增 在组件内定义 指定父组件调用时候的传值属性和事件类型
  model: {
    prop: 'value',
    event: 'change'
  },
  props: {
    value: {
      type: String,
      required: false
    },
    multiple: {
      type: Boolean,
      default: false,
      required: false
    },
    defaultFirst: {
      type: Boolean,
      default: false,
      required: false
    },
    clearable: {
      type: Boolean,
      default: true,
      required: false
    },
    filterable: {
      type: Boolean,
      default: false,
      required: false
    },
    size: {
      type: String,
      default: '',
      required: false
    },
    vxeMode: { // 是否为vxeMode使用类型场景, 默认为false
      type: Boolean,
      default: false,
      required: false
    },
    //  vxeParams vxe组件传递行和对应参数
    vxeParams: Object,
    renderOpts: Object
  },
  data() {
    return {
      options: {
        multiple: false,
        defaultFirst: false,
        clearable: true,
        filterable: true,
        size: 'mini'
      },
      tenantId: null,
      tenantList: [],
      row: null,
      column: null
    }
  },
  watch: {
    'options.multiple': {
      handler(multiple) {
        this.tenantId = multiple ? [] : ''
      },
      deep: true,
      immediate: true
    },
    row: {
      handler(val) {
        if (this.options.multiple) {
          this.tenantId = val && val[this.column.property] ? val[this.column.property].split(',') : []
        } else {
          this.tenantId = val && val[this.column.property] || ''
        }
      },
      deep: true
    },
    value: {
      handler(val) {
        if (this.multiple) {
          this.tenantId = !val ? [] : val.split(',')
        } else {
          this.tenantId = val || ''
        }
      },
      immediate: true
    }
  },
  created() {
    this.init()
  },
  methods: {
    init() {
      this.getTenantList()
      this.$nextTick(() => {
        this.propsInitData()
        this.initData()
      })
    },
    initData() {
      if (this.vxeMode) {
        const { row, column } = this.vxeParams
        this.row = row
        this.column = column
        const val = row[column.property]
        if (val) {
          this.tenantId = this.options.multiple ? val.split(',') : val
        } else {
          this.tenantId = this.options.multiple ? [] : ''
        }
      } else {
        if (this.options.multiple) {
          this.tenantId = !this.value ? [] : this.value.split(',')
        } else {
          this.tenantId = this.value || ''
        }
      }
    },
    propsInitData() {
      if (this.vxeMode) { //  vxe 调用组件时，根据传递的renderOpts，初始化data中的属性
        const { props } = this.renderOpts
        cloneDeep(this.options, props)
      } else {
        const { $props } = this
        cloneDeep(this.options, $props)
      }
    },
    async getTenantList() {
      const { data } = await findTenantList()
      this.tenantList = data
    },
    onChange(e) {
      const result = this.options.multiple ? e.join() : e

      if (this.vxeMode) {
        const { row, column } = this
        if (!row[column.property]) {
          Vue.set(row, column.property, result)
        } else {
          row[column.property] = result
        }
      } else {
        this.$emit('change', result)
      }
    }
  }
}
</script>
