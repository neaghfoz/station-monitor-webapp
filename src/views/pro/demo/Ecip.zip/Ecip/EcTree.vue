<template>
  <div class="tree-wrapper" style="padding: 0 50px;">
    <el-input
      v-if="treeData.length > 0"
      v-model="filterText"
      style="margin-bottom: 15px"
      clearable
      placeholder="输入名称进行过滤"
    />
    <el-tree
      ref="elTree"
      :data="treeData"
      :empty-text="emptyText"
      :show-checkbox="options.multiple"
      :check-strictly="options.checkStrictly"
      :default-expand-all="options.defaultExpandAll"
      :node-key="options.nodeKey"
      :default-expanded-keys="selections"
      :default-checked-keys="selections"
      :props="options.defaultProps"
      :filter-node-method="filterNode"
      @node-click="nodeClick"
    />
  </div>
</template>

<script>
import { getTreeData } from '@/api/sysrRquest'
import { filterNode } from '@/utils/tableUtil'

import { cloneDeep } from '@/utils'
export default {
  name: 'EcTree',
  model: {
    prop: 'value',
    event: 'change'
  },
  props: { //  后续再props新增接收属性，都需要在data中新增对应tm+属性名的对应映射的属性，并在propsInitData、vxeInitData中初始化
    value: {
      type: String, //  树选择id
      required: false
    },
    url: {
      type: String,
      required: false
    },
    params: {
      type: Object,
      default: () => {},
      required: false
    },
    data: {
      type: Object,
      default: () => {},
      required: false
    },
    excludeId: {
      type: String,
      required: false
    },
    title: {
      type: String,
      default: '选择树',
      required: false
    },
    nodeKey: {
      type: String,
      default: 'id',
      required: false
    },
    multiple: {
      type: Boolean,
      default: false,
      required: false
    },
    isPost: {
      type: Boolean,
      default: true,
      required: false
    },
    checkStrictly: {
      type: Boolean,
      default: true,
      required: false
    },
    defaultExpandAll: {
      type: Boolean,
      default: false,
      required: false
    },
    size: {
      type: String,
      default: '',
      required: false
    },
    attrName: {
      type: String,
      default: 'name',
      required: false
    },
    defaultProps: {
      type: Object,
      default: () => {
        return {
          children: 'children',
          label: 'name'
        }
      }
    }
  },
  data() {
    return {
      options: { // 以上为data属性对应 props属性
        url: '',
        isPost: true,
        title: '树选择',
        excludeId: '',
        attrName: 'name',
        size: 'mini',
        params: {},
        data: {},
        multiple: false,
        checkStrictly: true,
        defaultExpandAll: false,
        nodeKey: 'id',
        defaultProps: {
          children: 'children',
          label: 'name'
        }
      },
      visible: false,
      loading: false,
      filterText: '',
      tree: { id: '', name: '' },
      singleSelect: null,
      treeData: [],
      emptyText: this.loading ? '数据正在加载中...' : '暂无数据',
      selections: []
    }
  },
  watch: {
    filterText(val) {
      this.$refs.treeSelect.filter(val)
    },
    value: {
      handler(val) {
        if (val && this.multiple) {
          this.displayNode()
        }
      },
      immediate: true
    },
    loading(val) {
      this.emptyText = val ? '数据正在加载中...' : '暂无数据'
    }
  },
  created() {
    this.init()
  },
  methods: {
    async init() {
      this.$nextTick(() => {
        this.propsInitData()
        this.initModalData()
      })
    },
    initData() {
      // 初始化
      this.propsInitData()
      if (this.options.multiple) {
        this.$refs.treeSelect.setCheckedKeys([])
        this.displayNode()
      }
    },
    async initModalData() {
      await this.getTreeData()
    },
    displayNode() {
      const selecteds = []
      const ids = this.value ? this.value.split(',') : []

      this.recursion(ids, selecteds, this.treeData)

      // 处理已选中节点
      const treeId = selecteds.map(item => item.id).join()
      const treeName = selecteds.map(item => item[this.options.attrName]).join()
      this.selections = selecteds.map(item => item.id)
      this.tree = { id: treeId, name: treeName }
    },
    propsInitData() {
      const { $props } = this
      cloneDeep(this.options, $props)
    },
    recursion(ids, selections, tree) {
      if (tree) {
        tree.forEach(item => {
          if (ids.includes(item.id)) {
            selections.push(item)
          }
          if (item.children && item.children.length > 0) {
            this.recursion(ids, selections, item.children)
          }
        })
      }
    },
    async getTreeData() {
      this.loading = true
      const { data } = await getTreeData(this.options.url, Object.assign({}, { excludeId: this.options.excludeId },
        this.options.params), this.options.data, this.options.isPost)
      this.treeData = data
      this.displayNode()
      this.loading = false
    },
    nodeClick(node, Node) {
      this.$emit('node-click', node, Node)
    },
    filterNode(value, data, node) {
      return filterNode(value, data, node, this.options.defaultProps.label)
    },
    getTreeInstance() {
      return this.$refs.elTree
    }
  }
}
</script>

<style scoped>

</style>
