<template>
  <div>
    <el-input
      :size="options.size"
      class="detail-grid-width"
      :value="tree.name"
      :placeholder="options.title"
      type="text"
      readonly
      @focus="visible = true"
    >
      <el-button slot="append" icon="el-icon-search" @click="visible = true" />
    </el-input>

    <el-dialog
      ref="treeModal"
      :visible.sync="visible"
      :title="options.title"
      :width="'500px'"
      :append-to-body="!vxeMode"
      @opened="initData"
    >
      <div class="tree-wrapper" style="padding: 0 50px;">
        <el-input
          v-if="treeData.length > 0"
          v-model="filterText"
          style="margin-bottom: 15px"
          clearable
          placeholder="输入名称进行过滤"
        />
        <ec-tree
          ref="ecTree"
          :value="value"
          :url="url"
          :empty-text="emptyText"
          :show-checkbox="options.multiple"
          :check-strictly="options.checkStrictly"
          :default-expand-all="options.defaultExpandAll"
          :node-key="options.nodeKey"
          :default-expanded-keys="selections"
          :default-checked-keys="selections"
          :props="options.defaultProps"
          :filter-node-method="filterNode"
          @node-click="nodeClick"
        />
      </div>
      <div slot="footer">
        <el-button type="primary" @click="confirm">确定</el-button>
        <el-button type="default" @click="visible = false">关闭</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
/**
   * vxe-grid 每次编辑时，都会调取created钩子，所以vxe相关初始化应该在created钩子中进行；
   * 外部普通使用组件的时候，只有进入编辑页面第一次会执行created，后续重复点击modal都不会进入created钩子，故初始化需要放在dialog弹框弹出的时候执行；
   */
import { getTreeData } from '@/api/sysrRquest'
import { filterNode } from '@/utils/tableUtil'

import Vue from 'vue'
import { cloneDeep } from '@/utils'

export default {
  name: 'EcTreeModal',
  model: {
    prop: 'value',
    event: 'change'
  },
  props: { //  后续再props新增接收属性，都需要在data中新增对应tm+属性名的对应映射的属性，并在propsInitData、vxeInitData中初始化
    value: {
      type: String, //  树选择id
      required: false
    },
    url: {
      type: String,
      required: false
    },
    params: {
      type: Object,
      default: () => {},
      required: false
    },
    data: {
      type: Object,
      required: false
    },
    excludeId: {
      type: String,
      required: false
    },
    title: {
      type: String,
      default: '选择树',
      required: false
    },
    nodeKey: {
      type: String,
      default: 'id',
      required: false
    },
    multiple: {
      type: Boolean,
      default: false,
      required: false
    },
    isPost: {
      type: Boolean,
      default: true,
      required: false
    },
    checkStrictly: {
      type: Boolean,
      default: true,
      required: false
    },
    defaultExpandAll: {
      type: Boolean,
      default: false,
      required: false
    },
    size: {
      type: String,
      default: '',
      required: false
    },
    attrName: {
      type: String,
      default: 'name',
      required: false
    },
    defaultProps: {
      type: Object,
      default: () => {
        return {
          children: 'children',
          label: 'name'
        }
      }
    },
    vxeMode: { // 是否为vxeMode使用类型场景, 默认为false
      type: Boolean,
      default: false,
      required: false
    },
    //  vxeParams vxe组件传递行和对应参数
    vxeParams: Object,
    renderOpts: Object
  },
  data() {
    return {
      options: { // 以上为data属性对应 props属性
        url: '',
        isPost: true,
        title: '树选择',
        excludeId: '',
        attrName: 'name',
        size: 'mini',
        params: {},
        multiple: false,
        checkStrictly: true,
        defaultExpandAll: false,
        nodeKey: 'id',
        defaultProps: {
          children: 'children',
          label: 'name'
        }
      },
      visible: false,
      loading: false,
      filterText: '',
      tree: { id: '', name: '' },
      singleSelect: null,
      treeData: [],
      emptyText: this.loading ? '数据正在加载中...' : '暂无数据',
      selections: [],

      row: null,
      column: null
    }
  },
  watch: {
    $props: {
      handler(val) {
        this.$nextTick(() => {
          this.propsInitData()
        })
      },
      deep: true
    },
    filterText(val) {
      this.getElTreeInstance().filter(val)
    },
    'options.data.excludeId': {
      handler(val) {
        this.initModalData()
      },
      deep: true
    },
    value: {
      handler(val) {
        if (val && this.multiple) {
          this.displayNode()
        }
      },
      immediate: true
    },
    loading(val) {
      this.emptyText = val ? '数据正在加载中...' : '暂无数据'
    }
  },
  created() {
    this.init()
  },
  methods: {
    async init() {
      this.$nextTick(() => {
        this.propsInitData()
        this.initModalData()
      })
    },
    initData() {
      // 初始化
      this.propsInitData()
      if (this.options.multiple) {
        this.getElTreeInstance().setCheckedKeys([])
        this.displayNode()
      }
    },
    async initModalData() {
      await this.getTreeData()
    },
    displayNode() {
      const selecteds = []
      let ids = []
      if (this.vxeMode) {
        const { row, column } = this.vxeParams
        this.row = row
        this.column = column
        if (row[column.property] && row[column.property].id) {
          ids = row[column.property].id.split(',')
        }
      } else {
        ids = this.value ? this.value.split(',') : []
      }

      this.recursion(ids, selecteds, this.treeData)

      // 处理已选中节点
      const treeId = selecteds.map(item => item.id).join()
      const treeName = selecteds.map(item => item[this.options.attrName]).join()
      this.selections = selecteds.map(item => item.id)
      this.tree = { id: treeId, name: treeName }
    },
    propsInitData() {
      if (this.vxeMode) { //  vxe 调用组件时，根据传递的renderOpts，初始化data中的属性
        const { props } = this.renderOpts
        cloneDeep(this.options, props)
      } else {
        const { $props } = this
        cloneDeep(this.options, $props)
      }
    },
    recursion(ids, selections, tree) {
      if (tree) {
        tree.forEach(item => {
          if (ids.includes(item.id)) {
            selections.push(item)
          }
          if (item.children && item.children.length > 0) {
            this.recursion(ids, selections, item.children)
          }
        })
      }
    },
    async getTreeData() {
      this.loading = true
      const { data } = await getTreeData(this.options.url, Object.assign({}, { excludeId: this.options.excludeId },
        this.options.params), this.options.data, this.options.isPost)
      this.treeData = data
      this.displayNode()
      this.loading = false
    },
    nodeClick(node, Node) {
      if (!this.options.multiple) { //  单选的时候，点击事件会触发值的变更
        this.singleSelect = { id: node.id, name: node[this.options.defaultProps.label] }
      }
      this.$emit('node-click', node, Node)
    },
    filterNode(value, data, node) {
      return filterNode(value, data, node, this.options.defaultProps.label)
    },
    confirm() {
      if (this.options.multiple) {
        const checkedNodes = this.getElTreeInstance().getCheckedNodes()
        if (this.checkedNodes.length === 0) {
          this.$notify.warning('至少选择一个节点')
          return
        }

        const treeId = checkedNodes.map(item => item.id).join()
        const treeName = checkedNodes.map(item => item[this.options.attrName]).join()
        this.tree = { id: treeId, name: treeName }
      } else {
        Object.assign(this.tree, this.singleSelect)
      }

      this.emitChange()

      this.visible = false
    },
    emitChange() {
      if (this.vxeMode) {
        const { row, column } = this
        if (!row[column.property]) {
          Vue.set(row, column.property, this.tree)
        } else {
          row[column.property] = this.tree
        }
      } else {
        this.$emit('change', this.tree.id)
      }
    },
    getElTreeInstance() {
      return this.$refs.ecTree.getTreeInstance()
    }
  }
}
</script>
