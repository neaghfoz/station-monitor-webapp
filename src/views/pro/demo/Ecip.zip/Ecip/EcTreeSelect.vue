<template>
  <el-input
    v-if="object"
    class="detail-grid-width"
    :value="object[fieldName] && object[fieldName].name"
    :placeholder="title"
    type="text"
    :size="size"
    readonly
    @focus="treeSelectPlus(object, fieldName, title, treeDataUrl, excludeId, Object.assign({}, { multiple: multiple }, params || {}), treeChange, isPost)"
  />
  <el-input v-else :size="size" class="detail-grid-width" :value="tree.name" :placeholder="title" type="text" readonly @focus="treeSelect(tree, title, treeDataUrl, excludeId, multiple, treeChange, params, isPost)" />

</template>

<script>
import { treeSelect, treeSelectPlus } from '../SelectDialog'
import { findTreeDataByIds } from '@/api/sysrRquest'

export default {
  name: 'EcTreeSelect',
  model: {
    prop: 'value',
    event: 'change'
  },
  props: {
    value: {
      type: [String, Object], //  树选择id
      required: false
    },
    object: {
      type: Object
    },
    fieldName: {
      type: String
    },
    attrName: { // 树对象展示的java字段名
      type: String,
      default: 'name'
    },
    url: {
      type: String,
      required: true
    },
    params: {
      type: Object
    },
    excludeId: {
      type: String
    },
    title: {
      type: String,
      default: '选择树'
    },
    multiple: {
      type: Boolean,
      default: false
    },
    isPost: {
      type: Boolean,
      default: true
    },
    size: {
      type: String,
      default: '',
      required: false
    }
  },
  data() {
    return {
      treeDataUrl: this.url && this.url.lastIndexOf('/data') !== -1
        ? this.url : this.url.concat('/data'),
      treeIdsUrl: this.url && this.url.lastIndexOf('/data') !== -1
        ? this.url.replace('/data', '/findDataByIds') : this.url.concat('/findDataByIds'),
      tree: { id: '', name: '' }
    }
  },
  watch: {
    url(val) {
      this.treeDataUrl = val && val.lastIndexOf('/data') !== -1 ? val : val.concat('/data')
      this.treeIdsUrl = val && val.lastIndexOf('/data') !== -1 ? val.replace('/data', '/findDataByIds') : val.concat('/findDataByIds')
    },
    async value(val) {
      if (val) {
        if (typeof val === 'string') {
          const { data } = await findTreeDataByIds(this.treeIdsUrl, val)
          const treeId = data.map(item => item.id).join()
          const treeName = data.map(item => item[this.attrName]).join()
          this.tree = { id: treeId, name: treeName }
        } else if (typeof val === 'object') {
          this.tree = val
        }
      } else {
        this.tree = { id: '', name: '' }
      }
    }
  },
  methods: {
    treeSelect,
    treeSelectPlus,
    treeChange(e) {
      this.$emit('change', e && e.id)
    }
  }
}
</script>

<style scoped>

</style>
