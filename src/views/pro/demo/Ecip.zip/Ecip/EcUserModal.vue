<template>
  <div>
    <!--用户选择input框-->
    <el-input
      :size="options.size"
      class="detail-grid-width"
      :value="user.realName"
      placeholder="用户选择"
      type="text"
      readonly
      @focus="visible = true"
    >
      <el-button slot="append" icon="el-icon-search" @click="visible = true" />
    </el-input>

    <!--用户选择数据modal-->
    <el-dialog
      ref="userModal"
      :visible.sync="visible"
      title="用户选择"
      width="80%"
      :append-to-body="!vxeMode"
      @opened="initModalData"
    >
      <el-row :gutter="24">
        <el-col :span="6">
          <el-card shadow="never" style="max-height: 770px; overflow: auto">
            <el-input
              v-if="deptTreeList.length > 0"
              v-model="deptFilterText"
              style="margin-bottom: 15px"
              clearable
              placeholder="输入名称进行过滤"
            />
            <el-tree
              ref="deptTree"
              :props="{ label: 'name', children: 'children'} "
              :data="deptTreeList"
              :expand-on-click-node="false"
              :filter-node-method="filterNode"
              node-key="id"
              @node-click="deptClick"
            />
          </el-card>
        </el-col>
        <el-col :span="13">
          <el-card shadow="never">
            <el-form ref="searchForm" :model="queryParams" inline :label-width="'100px'">
              <el-form-item label="租户" prop="tenantId">
                <ec-tenant v-model="queryParams.tenantId" @change="getDeptTree" />
              </el-form-item>
              <el-form-item label="系统">
                <ec-register-app v-model="queryParams.appId" clearable filterable default-first :tenant-id="queryParams.tenantId" @hasInit="getUserData('init')" @change="getUserData('change')" />
              </el-form-item>
              <el-form-item label="用户帐号" prop="username">
                <el-input v-model="queryParams.username" type="text" placeholder="用户帐号" />
              </el-form-item>
              <el-form-item label="用户姓名" prop="realName">
                <el-input v-model="queryParams.realName" type="text" placeholder="用户姓名" />
              </el-form-item>
              <el-form-item label="手机号码" prop="phone">
                <el-input v-model="queryParams.phone" type="text" placeholder="手机号码" />
              </el-form-item>
              <el-form-item label="邮箱" prop="email">
                <el-input v-model="queryParams.email" type="text" placeholder="邮箱" />
              </el-form-item>
              <el-form-item class="searchItem">
                <el-button type="primary" @click="getUserData">查询</el-button>
                <el-button type="default" @click="handleReset">重置</el-button>
              </el-form-item>
            </el-form>

            <vxe-grid
              id="vxe"
              ref="vxe"
              highlight-hover-row
              border
              show-overflow
              show-header-overflow
              resizable
              row-id="id"
              sync-resize
              auto-resize
              class="vxe-table-element"
              :loading="loading"
              :start-index="(page.currentPage - 1) * page.pageSize"
              :pager-config="page"
              :columns="columns"
              :data="userData"
              :checkbox-config="{ reserve: true }"
              @page-change="handlePageChange"
              @checkbox-change="checkboxChange"
              @checkbox-all="checkboxAll"
            />
          </el-card>
        </el-col>
        <el-col :span="5">
          <el-card shadow="never" style="max-height: 770px; overflow: auto">
            <div slot="header">
              <span>已选用户</span>
              <el-button class="pull-right" size="medium" type="text" @click="clearChoose">清空操作</el-button>
            </div>
            <template v-for="(item, index) in selections">
              <el-row :key="item.id">
                <el-col :span="14">
                  <span>{{ item.realName }}</span>
                </el-col>
                <el-col :offset="3" :span="7">
                  <span style="cursor: pointer" @click="removeOne(item.id, index)"><i class="el-icon-remove-outline" /></span>
                </el-col>
              </el-row>
            </template>
          </el-card>
        </el-col>
      </el-row>
      <div slot="footer">
        <el-button type="primary" @click="confirm">确定</el-button>
        <el-button type="default" @click="visible = false">关闭</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import Vue from 'vue'
import { findUserByIds as findDataByIds, findAppDeptTree, getUserPage as userPage } from '@/api/sysrRquest'
import { cloneDeep } from '@/utils'
import { filterNode } from '@/utils/tableUtil'
/**
   * vxe-grid 每次编辑时，都会调取created钩子，所以vxe相关初始化应该在created钩子中进行；
   * 外部普通使用组件的时候，只有进入编辑页面第一次会执行created，后续重复点击modal都不会进入created钩子，故初始化需要放在dialog弹框弹出的时候执行；
   */
export default {
  name: 'EcUserModal',
  model: {
    prop: 'value',
    event: 'change'
  },
  props: { //  后续再props新增接收属性，都需要在data中新增对应um+属性名的对应映射的属性，并在propsInitData、vxeInitData中初始化
    // 以下为非vxe组件传递行和对应参数
    value: {
      type: String,
      required: false
    },
    multiple: {
      type: Boolean,
      default: false,
      required: false
    },
    params: {
      type: Object,
      default: () => {},
      required: false
    },
    attrName: {
      type: String,
      default: 'realName',
      required: false
    },
    size: {
      type: String,
      default: '',
      required: false
    },
    vxeMode: { // 是否为vxeMode使用类型场景, 默认为false
      type: Boolean,
      default: false,
      required: false
    },
    //  vxeParams vxe组件传递行和对应参数
    vxeParams: Object,
    renderOpts: Object
  },
  data() {
    return {
      isEmit: false,
      options: {
        multiple: false,
        size: 'mini',
        params: {},
        attrName: 'realName'
      },
      recordIds: new Set(),
      // 以上为data属性对应 props属性
      visible: false, //  用户数据modal是否可见
      loading: false, //  数据请求加载状态
      userData: [], //  后台返回的用户数据
      deptTreeList: [], //  后台返回的组织数据
      selections: [],
      columns: [
        { type: 'checkbox', width: 40, fixed: 'left', align: 'center' },
        { title: '用户名', field: 'username', minWidth: 180, showOverflow: true },
        { title: '姓名', field: 'realName', minWidth: 180, showOverflow: true },
        { title: '性别', field: 'sexText', minWidth: 180, showOverflow: true },
        { title: '手机号', field: 'phone', minWidth: 180, showOverflow: true },
        { title: '邮箱', field: 'email', minWidth: 180, showOverflow: true }
      ],
      page: {
        total: 0,
        currentPage: 1,
        pageSize: 10,
        align: 'left',
        pageSizes: [10, 20, 50, 100, 200, 500],
        layouts: ['Sizes', 'PrevJump', 'PrevPage', 'Number', 'NextPage', 'NextJump', 'FullJump', 'Total'],
        perfect: true
      },
      queryParams: {}, //  用户选择查询条件： 用户名查询，用户真实姓名查询
      // ================================= 下面对数据接收，和已选择数据做对应处理 ======================================
      user: { id: '', realName: '' },
      deptFilterText: '',
      row: null,
      column: null
    }
  },
  watch: {
    // selections: {
    //   handler(val) {
    //     val.forEach(item => this.recordIds.add(item.id))
    //   }
    // },
    deptFilterText(val) {
      this.$refs.deptTree.filter(val)
    },
    $props: {
      handler(val) {
        this.$nextTick(() => {
          this.propsInitData()
        })
      },
      deep: true
    },
    value: {
      handler(val) {
        if (this.isEmit) {
          this.isEmit = false
          return
        }
        if (val) {
          this.getUsersByIds(val)
        }
      },
      immediate: true
    }
  },
  created() {
    this.init()
  },
  methods: {
    init() { //  组件创建时初始化, 组件创建时，必须根据id去查询对应用户，用于数据回显
      this.propsInitData()
    },
    propsInitData() { //  初始化组件参数，在组件创建时调用，一般只初始化一次
      if (this.vxeMode) { //  vxe 调用组件时，根据传递的renderOpts，初始化data中的属性
        const { props } = this.renderOpts
        cloneDeep(this.options, props)
      } else { //  html 直接调用组件时，根据传递的props参数初始化data中的属性
        const { $props } = this
        cloneDeep(this.options, $props)
      }
    },
    async initModalData() { // dialog 弹出时，调用方法
      this.initData()
      await this.getDeptTree()
      await this.getUsersByIds(this.value)
      await this.getUserData()
    },
    setDefaultChecked() {
      const selecteds = this.userData.filter(item => this.recordIds.has(item.id))
      this.$nextTick(() => {
        if (selecteds.length === 0) {
          this.$refs.vxe.setCheckboxRow(...this.recordIds, true)
        } else {
          this.$refs.vxe.setCheckboxRow(selecteds, true)
        }
        // this.selections = this.$refs.vxe.getCheckboxReserveRecords().concat(this.$refs.vxe.getCheckboxRecords())
        // console.log(this.$refs.vxe.getCheckboxReserveRecords())
        // console.log(this.$refs.vxe.getCheckboxRecords())
      })
      // if (selecteds.length !== 0) {
      //   const userId = selecteds.map(item => item.id).join()
      //   const userRealName = selecteds.map(item => item[this.options.attrName]).join()
      //   this.user = { id: userId, realName: userRealName }
      // }
    },
    initData() { //  dialog 关闭时，需要进行的初始化操作， 需要初始化： 搜索条件、用户列表、树列表、已选状态、分页状态
      this.queryParams = {}
      this.selections = []
      this.recordIds = new Set()
      this.userData = []
      this.deptTree = []
      // this.selections = this.user && this.user.id ? [this.user] : []
      // 初始化已选用户
      this.page = {
        total: 0,
        currentPage: 1,
        pageSize: 10,
        align: 'left',
        pageSizes: [10, 20, 50, 100, 200, 500],
        layouts: ['Sizes', 'PrevJump', 'PrevPage', 'Number', 'NextPage', 'NextJump', 'FullJump', 'Total'],
        perfect: true
      }
      this.$nextTick(() => {
        this.$refs.vxe.clearCheckboxRow()
        this.$refs.vxe.clearCheckboxReserve()
      })

      // if (this.vxeMode) {
      //   const { row, column } = this.vxeParams
      //   this.row = row
      //   this.column = column
      //   if (row[column.property] && row[column.property].id) {
      //     this.recordIds = row[column.property].id.split(',')
      //   }
      // } else {
      //   this.recordIds = this.value ? this.value.split(',') : []
      // }
    },
    async getUsersByIds(ids) {
      if (ids && ids.length > 0) {
        // 根据传入id，查询已选用户
        const { data } = await findDataByIds(ids)
        const userIds = []
        const userRealNames = []
        this.selections = data
        data.forEach(item => {
          this.recordIds.add(item.id)
          userIds.push(item.id)
          userRealNames.push(item[this.options.attrName])
        })
        this.user = { id: userIds.join(), realName: userRealNames.join() }
      }
    },
    async getUserData(type) {
      try {
        this.loading = true
        const { data } = await userPage(Object.assign({}, this.options.params, { size: this.page.pageSize, current: this.page.currentPage }), Object.assign({}, this.queryParams))
        this.userData = data.records
        this.page.total = data.total
        this.setDefaultChecked()
      } finally {
        this.loading = false
      }
    },
    async getDeptTree() {
      try {
        this.loading = true
        const { data } = await findAppDeptTree({ tenantId: this.queryParams.tenantId })
        this.deptTreeList = data
      } finally {
        this.loading = false
      }
    },
    deptClick(node, Node) {
      // this.queryParams.deptId = node[0].id
      // this.getUserData()

      if (Node.level && Node.level !== 1) {
        this.queryParams.deptId = node.id
        this.getUserData()
      }
    },
    handleReset() {
      this.$refs.searchForm.resetFields()
      this.getDeptTree()
    },
    handlePageChange({ currentPage, pageSize }) {
      this.page.currentPage = currentPage
      this.page.pageSize = pageSize
      this.getUserData()
    },
    removeOne(userId, index) {
      this.selections.splice(index, 1)
      this.recordIds.delete(userId)
    },
    checkboxChange({ checked, row }) {
      if (checked) {
        this.selections.push(row)
        this.recordIds.add(row.id)
      } else {
        this.selections = this.selections.filter(item => row.id !== item.id)
        this.recordIds.delete(row.id)
      }
    },
    checkboxAll({ checked }) {
      this.userData.forEach(item => {
        if (checked) {
          if (!this.recordIds.has(item.id)) {
            this.recordIds.add(item.id)
            this.selections.push(item)
          }
        } else {
          const userIds = []
          this.userData.forEach(item => {
            userIds.push(item.id)
            this.recordIds.delete(item.id)
          })
          this.selections = this.selections.filter(item => !userIds.includes(item.id))
        }
      })
    },
    clearChoose() {
      this.$refs.vxe.clearSelection()
      this.selections = []
    },
    confirm() {
      // const selecteds = this.$refs.vxe.getCheckboxReserveRecords().concat(this.$refs.vxe.getCheckboxRecords())
      const selecteds = this.selections
      if (!this.options.multiple && selecteds.length > 1) {
        this.$notify.warning('只能选择一个用户')
        return
      }

      const userIds = []
      const userRealNames = []
      selecteds.forEach(item => {
        userIds.push(item.id)
        userRealNames.push(item[this.options.attrName])
      })
      // const userId = selecteds.map(item => item.id).join()
      // const realName = selecteds.map(item => item[this.options.attrName]).join()
      this.user = { id: userIds.join(), realName: userRealNames.join() }
      if (this.vxeMode) {
        const { row, column } = this
        if (!row[column.property]) {
          Vue.set(row, column.property, this.user)
        } else {
          row[column.property] = this.user
        }
      } else {
        this.isEmit = true
        this.$emit('change', this.user.id)
      }
      this.visible = false
    },
    close() {
      this.initData()
    },
    filterNode(value, data, node) {
      return filterNode(value, data, node, 'name')
    },
    getCurrentUser() {
      return this.user
    }
  }

}
</script>

<style scoped>

</style>
