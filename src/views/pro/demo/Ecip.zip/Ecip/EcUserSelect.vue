<template>
  <div>
    <el-input
      v-if="object"
      class="detail-grid-width"
      :value="object[fieldName] && object[fieldName].realName || ''"
      placeholder="用户选择"
      type="text"
      :size="size"
      readonly
      @focus="userSelectPlus(object, fieldName, Object.assign({}, { multiple: multiple }, params || {}), userChange, searchByTenant)"
    />
    <el-input v-else :size="size" class="detail-grid-width" :value="user.realName" placeholder="用户选择" type="text" readonly @focus="userSelect(user, multiple, userChange, params, searchByTenant)" />
  </div>
</template>

<script>
import { userSelectPlus, userSelect } from '../SelectDialog'
import { findUserByIds } from '@/api/sysrRquest'

export default {
  name: 'EcUserSelect',
  model: {
    prop: 'value',
    event: 'change'
  },
  props: {
    value: { //  用户id/ids
      type: [String, Object],
      required: false
    },
    object: {
      type: Object
    },
    multiple: {
      type: Boolean,
      default: false
    },
    searchByTenant: {
      type: Boolean,
      default: false
    },
    fieldName: {
      type: String
    },
    params: {
      type: Object
    },
    size: {
      type: String,
      default: '',
      required: false
    }
  },
  data() {
    return {
      user: { id: '', realName: '' }
    }
  },
  watch: {
    async value(val) {
      if (val) {
        if (typeof val === 'string') {
          const { data } = await findUserByIds(val)
          const userId = data.map(item => item.id).join()
          const userRealName = data.map(item => item.realName).join()
          this.user = { id: userId, realName: userRealName }
        } else if (typeof val === 'object') {
          this.user = val
        }
      } else {
        this.user = { id: '', realName: '' }
      }
    }
  },
  methods: {
    userSelect,
    userSelectPlus,
    userChange(e) {
      this.$emit('change', e && e.id)
    }
  }
}
</script>

<style scoped>

</style>
